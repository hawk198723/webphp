<?php
$dbh = new PDO("mysql:host=localhost;dbname=webdfinal", 'root', 'root');
echo 'Database Status: Connected';
echo "<br>"
?>
