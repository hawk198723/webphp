<?php
error_reporting(0);
session_start();
$sessid = session_id();
$dbh = new PDO("mysql:host=localhost;dbname=mc_cart", "root", "root");
$admin = 'mesa_admin';
$categories = 'mesa_categories';
$products = 'mesa_products';
$cartitems = 'mesa_cartitems';

?>