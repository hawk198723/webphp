<script>
var rec = localStorage.getItem('recent');
document.write('<h3>Recent Searches:</h3>' + rec);
</script>